//
//  SectionHeaderView.swift
//  HDAssign
//
//  Created by Raja Nukala on 2/27/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import UIKit

class SectionHeaderView: UICollectionReusableView {
    
    @IBOutlet weak var sectionTitle: UILabel!
    
}
