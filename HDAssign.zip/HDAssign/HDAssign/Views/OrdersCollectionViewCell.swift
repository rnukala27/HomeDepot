//
//  OrdersCollectionViewCell.swift
//  HDAssign
//
//  Created by Raja Nukala on 2/26/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import UIKit

class OrdersCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var orderLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    
    var order:Order!{
        didSet{
            orderLabel.text = order.getOrderText()
            totalLabel.text = order.getTotaltext()
            backgroundColor = order.getBackgroundColor()
        }
    }
}
