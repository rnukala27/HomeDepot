//
//  OrdersManager.swift
//  HDAssign
//
//  Created by Raja Nukala on 2/26/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import Foundation

class OrdersManager {
    
    private init() { }       // To aviod another instances.
    
    static var shared = OrdersManager()
    
    func getData(with completionHander: (_ data: Array<Order>) -> ()) {
        guard let path = Bundle.main.path(forResource: "LocalJSON", ofType: "json") else {
            completionHander([])
            return }
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .alwaysMapped)
            let root = try JSONDecoder().decode(Welcome.self, from: data)
            completionHander(root.orders)
        } catch {
            completionHander([])
            print(error.localizedDescription)
        }
    }
}
