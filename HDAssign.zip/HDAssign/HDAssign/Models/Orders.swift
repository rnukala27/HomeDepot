//
//  Orders.swift
//  HDAssign
//
//  Created by Raja Nukala on 2/26/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import Foundation
import UIKit

// MARK: - Welcome
struct Welcome: Codable {
    let orders: [Order]
}

// MARK: - Order
struct Order: Codable{
        
    let orderID: String?    
    let status: Status
    let orderTotal: Double?
    let orderStatus: OrderStatus?
    let type, storeNumber, registerNumber, transactionNumber: String?
    let total: Double?
    var date:Date!
    
    enum CodingKeys: String, CodingKey {
        case orderID = "orderId"
        case orderDate, status, orderTotal, orderStatus, type, storeNumber, registerNumber, transactionNumber, date, total
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        orderID = try? container.decode(String.self, forKey: .orderID)
        
        if let dateString = try? container.decode(String.self, forKey: .date){
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            if let date = dateFormatter.date(from: dateString){
                self.date = date
            }
            
        }
        if let dateString = try? container.decode(String.self, forKey: .orderDate){
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            if let date = dateFormatter.date(from: dateString){
                self.date = date
            }
            
        }
        
        status = try container.decode(Status.self, forKey: .status)
        orderStatus = try? container.decode(OrderStatus.self, forKey: .orderStatus)
        type = try? container.decode(String.self, forKey: .type)
        storeNumber = try? container.decode(String.self, forKey: .storeNumber)
        registerNumber = try? container.decode(String.self, forKey: .registerNumber)
        transactionNumber  = try? container.decode(String.self, forKey: .transactionNumber)
        
        total  = try? container.decode(Double.self, forKey: .total)
        orderTotal  = try? container.decode(Double.self, forKey: .orderTotal)
                
    }
    func encode(to encoder: Encoder) throws {
        
    }
    
    var datekey:String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM dd, yyyy"// yyyy-MM-dd"
        return dateFormatter.string(from: date)
    }

    func getOrderText() -> String{
        var orderText = ""
        if let orderNum = self.orderID {
             orderText = "Order # : " + orderNum
        }else{
            if let storeNum = self.storeNumber,
                let registerNum = self.registerNumber,
                let transactionNum = self.storeNumber {
                orderText = "Receipt # : " + storeNum + registerNum + transactionNum
            }
        }
        return orderText
    }
    
    func getTotaltext() -> String{
        var totaltext = ""
        if let total = self.orderTotal {
            totaltext = "Total: $" + String(total)
        }else if let total = self.total{
            totaltext = "Total: $" + String(total)
        }
        return totaltext
    }
    
    func getBackgroundColor() -> UIColor {
        if self.total != nil{
            return .cyan
        }
        return UIColor.green
    }
}

enum OrderStatus: String, Codable {
    case placed = "PLACED"
    case transmitted = "TRANSMITTED"
}

enum Status: String, Codable {
    case complete = "Complete"
    case transmitted = "TRANSMITTED"
}
