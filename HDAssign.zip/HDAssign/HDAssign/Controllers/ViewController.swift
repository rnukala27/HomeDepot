//
//  ViewController.swift
//  HDAssign
//
//  Created by Raja Nukala on 2/26/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    let cellReuseIdentifier = "cell"
    let sectionHeaderViewIdentifier = "SectionHeader"
    
    var items: [Order] = []
    var datasorceList = [String: [Order]]()
    var allGroups = [String]()

    @IBOutlet var collectionView: UICollectionView!
    
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        fetchData()
    }
    
    func fetchData() {
        OrdersManager.shared.getData {[weak self] orders in
            guard let self = self else { return }
            if orders.count > 0 {
                self.items = orders
                self.createGroups()
                self.allGroups = Array(self.datasorceList.keys)
            } else {
                // print(error)
            }
        }
    }
    
    func createGroups() {
       items = items.sorted { (f, s) -> Bool in
            return f.date.compare(s.date) == .orderedDescending
        }
        for order in items {
            if var values = datasorceList[order.datekey] {
                values.append(order)
                datasorceList[order.datekey] = values
            } else {
                datasorceList[order.datekey] = [order]
            }
        }
    }
    
    // MARK: - UICollectionView DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return self.datasorceList.keys.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let dataitems = self.datasorceList[allGroups[section]]
        return dataitems?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellReuseIdentifier, for: indexPath) as! OrdersCollectionViewCell
        
        let dataitems = self.datasorceList[allGroups[indexPath.section]]
        if let order = dataitems?[indexPath.row]{
            cell.order = order
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionView.elementKindSectionHeader {
            
            let sectionHeaderView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: sectionHeaderViewIdentifier, for: indexPath) as! SectionHeaderView
            
            sectionHeaderView.sectionTitle.text = allGroups[indexPath.section]
            sectionHeaderView.backgroundColor = UIColor.gray
            return sectionHeaderView
            
        } else {
            return UICollectionReusableView()
        }
    }
    
    // MARK: - UICollectionView Delegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
}

