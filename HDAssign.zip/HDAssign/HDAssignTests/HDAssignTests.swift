//
//  HDAssignTests.swift
//  HDAssignTests
//
//  Created by Raja Nukala on 2/26/20.
//  Copyright © 2020 RajaNukala. All rights reserved.
//

import XCTest

@testable import HDAssign
class HDAssignTests: XCTestCase {
    
    var order1:Order!
    override func setUp() {
        let jsonString = "{ \"orderId\": \"WD12820563\", \"orderDate\" : \"2018-07-28T16:39:06Z\", \"status\" : \"TRANSMITTED\", \"orderTotal\" : 7.61, \"orderStatus\" : \"PLACED\", \"type\" : \"COM\" }"
        let jsonData = jsonString.data(using: .utf8)!
        
        do {
            let jsonDecoder = JSONDecoder()
            order1 = try jsonDecoder.decode(Order.self, from: jsonData)
        } catch {
            print("Unexpected error: \(error).")
        }
    }

    
    func checkOrderNumber() {
        if let id = order1.orderID{
            XCTAssertNotNil(order1.getOrderText(), "Order # : " + id)
        }
    }
    
    func checkTotal() {
        if let total = order1.orderTotal{
            XCTAssertNotNil(order1.getTotaltext(), "Total: $ \(total)")
        }
        if let total = order1.total{
            XCTAssertNotNil(order1.getTotaltext(), "Total: \(total)")
        }
    }
}
